package com.example.crudusuario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormularioSpringMvcDataSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormularioSpringMvcDataSecurityApplication.class, args);
	}

}
